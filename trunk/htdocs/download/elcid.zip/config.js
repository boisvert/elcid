/*

 Site configuration
 by Charles Boisvert 
 Created: 31 March 2008

*/

var cgiURL = 'http://www.boisvert.me.uk/cgi/';
var htURL = '';

