eL-CID - e-Learning by Communicating Iterative Development

Readme
======

Thank you for downloading!

To install, unzip in a folder of your choice. Click on index.html to follow links to the existing examples or elcid.shtml to start running.

The samples folder contains example XML files to help demonstrate code development. If you make your own XML examples, save them in the same folder - this is the folder that the system loads from.

eL-CID has been tested on Mozilla 1.4, Safari 1.2, Internet Explorer 5.5 and later.

The licensing of eL-CID is open source except that you may create your own development examples and exploit them commercially - see the source for details. The XML examples included are in the public domain.

Charles Boisvert,
Cboisver@ccn.ac.uk

